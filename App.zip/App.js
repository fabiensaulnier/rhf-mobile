import React , { Component } from 'react';
import { Platform, StyleSheet, Text, View, Alert, Button } from 'react-native';
import Table from 'react-native-simple-table'
const columns = [
  {
    title: '#',
    dataIndex: 'position'    
  },
  {
    title: 'Équipe',
    dataIndex: 'equipe',
    width: 100
  },
  {
    title: 'MJ',
    dataIndex: 'matchFini',
    width: 50
  },
  {
    title: 'PTS',
    dataIndex: 'point',
    width: 40
  },
  {
    title: 'V',
    dataIndex: 'victoire'
  },
  {
    title: 'Vp',
    dataIndex: 'victoireProlongation'
  },
  {
    title: 'D',
    dataIndex: 'defaite'
  },
];

export default class App extends React.Component {
  SampleFunction=(item)=>{
    
       Alert.alert(item);
    
     }
  render() {
    var EquipesElite = [{position:1,equipe:"Rethel",matchFini:0,point:0,victoire:0,defaite:0,victoireProlongation:0},
                        {position:1,equipe:"Grenoble",matchFini:0,point:0,victoire:0,defaite:0,victoireProlongation:0},
                        {position:1,equipe:"Anglet",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Epernay",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Bordeaux",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Caen",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Villeneuve-la-garenne",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Paris",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Garges",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0},
                        {position:1,equipe:"Angers",matchFini:0,point:0,victoire:0,defaite:0, victoireProlongation:0}
                      ];
    var EquipeN1 = [];
    var EquipeN2 = [];
    var EquipeN3 = [];
    var EquipeN4 = [];        
         
    return (
      <View style={styles.container}>

        <Text style={styles.title}> Statistiques - Championnat Élite - 2018-2019</Text>
        <Table height={320} columnWidth={30} columns={columns} dataSource={EquipesElite} />

        <Button
          title="Classement"
          color="#000"
          accessibilityLabel="Classement"
          style={styles.Button}
        />
        <Button
          title="Résultat"
          color="#000"
          accessibilityLabel="Résultat"
        />
        <Button
          title="Statistiques"
          color="#000"
          accessibilityLabel="Statistiques"
        />
       

{/* 
<Text>Open uppppp App.js to start working on your app!</Text>
        <Text>Changes you make will automatically reload.</Text>
        <Text>Shake your phone to open the developer menu.</Text> */


        // { EquipesElite.map((item, key)=>(
        //   <Text key={key} style={styles.TextStyle} onPress={ this.SampleFunction.bind(this, item) }> { item } </Text>)
        //   )}
        
        }
      </View>
      
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EEE',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop:25
  },
  TextStyle:{
    fontSize : 25,
     textAlign: 'center'
  },
  title: {
    fontSize: 18,
    padding: 10,
    textAlign: 'center'
  }
});
